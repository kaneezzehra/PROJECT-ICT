#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main()
{
    ifstream abubakr("11a.txt")
    if(abubakr.is_open)
    {
        string line;
        while(getline(abubakr,line))
        cout<<line<<endl;

    }
    else
    {
        cout<<"error opening";
    }
}